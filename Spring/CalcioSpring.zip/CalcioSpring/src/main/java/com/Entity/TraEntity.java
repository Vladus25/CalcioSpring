package com.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "tra")
public class TraEntity {
	
	@Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
	
	@ManyToOne
    @JoinColumn(name = "id_squadra")
    private SquadraEntity squadra;

    @ManyToOne
    @JoinColumn(name = "id_partita")
    private PartitaEntity partita;

    @Column(name = "gioca_in_casa")
    private boolean giocaInCasa;
    
    

	public Integer getId() {
		return id;
	}



	public void setId(Integer id) {
		this.id = id;
	}



	public SquadraEntity getSquadra() {
		return squadra;
	}



	public void setSquadra(SquadraEntity squadra) {
		this.squadra = squadra;
	}



	public PartitaEntity getPartita() {
		return partita;
	}



	public void setPartita(PartitaEntity partita) {
		this.partita = partita;
	}



	public boolean isGiocaInCasa() {
		return giocaInCasa;
	}



	public void setGiocaInCasa(boolean giocaInCasa) {
		this.giocaInCasa = giocaInCasa;
	}



	public TraEntity(Integer id, SquadraEntity squadra, PartitaEntity partita, boolean giocaInCasa) {
		super();
		this.id = id;
		this.squadra = squadra;
		this.partita = partita;
		this.giocaInCasa = giocaInCasa;
	}

	public TraEntity() {
		super();
	}
    
}
