package com.Entity;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "giocatori")
public class GiocatoreEntity {
	
	@Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
	
	@Column(name = "nome", nullable = false, length = 50)
    private String nome;
	
	@Column(name = "cognome", nullable = false, length = 50)
    private String cognome;
	
	@Column(name = "data_n", nullable = false, length = 50)
    private LocalDate DataN;
	
	@Column(name = "ruolo", nullable = false, length = 50)
    private String ruolo;
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_squadra")
    private SquadraEntity idSquadra;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public LocalDate getDataN() {
		return DataN;
	}

	public void setDataN(LocalDate dataN) {
		DataN = dataN;
	}

	public String getRuolo() {
		return ruolo;
	}

	public void setRuolo(String ruolo) {
		this.ruolo = ruolo;
	}

	public SquadraEntity getIdSquadra() {
		return idSquadra;
	}

	public void setIdSquadra(SquadraEntity idSquadra) {
		this.idSquadra = idSquadra;
	}

	public GiocatoreEntity(Integer id, String nome, String cognome, LocalDate dataN, String ruolo,
			SquadraEntity idSquadra) {
		super();
		this.id = id;
		this.nome = nome;
		this.cognome = cognome;
		this.DataN = dataN;
		this.ruolo = ruolo;
		this.idSquadra = idSquadra;
	}

	public GiocatoreEntity() {
		super();
	}
	
	
	
}
