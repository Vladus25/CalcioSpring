package com.Entity;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "partite")
public class PartitaEntity {
	
	@Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
	
	@Column(name = "girone", nullable = false, length = 50)
    private Integer girone;
	
	@Column(name = "nome", nullable = false, length = 50)
	private Integer giornata;
	
	@Column(name = "data", nullable = true)
    private LocalDate data;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getGirone() {
		return girone;
	}

	public void setGirone(Integer girone) {
		this.girone = girone;
	}

	public Integer getGiornata() {
		return giornata;
	}

	public void setGiornata(Integer giornata) {
		this.giornata = giornata;
	}

	public LocalDate getData() {
		return data;
	}

	public void setData(LocalDate data) {
		this.data = data;
	}

	public PartitaEntity(Integer id, Integer girone, Integer giornata, LocalDate data) {
		super();
		this.id = id;
		this.girone = girone;
		this.giornata = giornata;
		this.data = data;
	}

	public PartitaEntity() {
		super();
	}
	
	
	
}
