package com.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Entity.TraEntity;
import com.Repository.TraRepository;

@Service
public class TraService {
	
	@Autowired
    private TraRepository repo;
	
	 public List<TraEntity> getAll(){
	        return repo.findAll();
	 }
}
