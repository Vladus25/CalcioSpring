package com.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Entity.GiocatoreEntity;

public interface GiocatoreRepository extends JpaRepository<GiocatoreEntity, Integer>{

}
