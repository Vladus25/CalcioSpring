package com.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Entity.PartitaEntity;

public interface PartitaRepository extends JpaRepository<PartitaEntity, Integer>{

}
