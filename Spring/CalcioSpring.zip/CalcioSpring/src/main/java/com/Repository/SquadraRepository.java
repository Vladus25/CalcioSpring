package com.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Entity.SquadraEntity;

public interface SquadraRepository extends JpaRepository<SquadraEntity, Integer>{

}
